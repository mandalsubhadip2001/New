
document.getElementById("submit-button").addEventListener("click", function() {
    var url = document.getElementById("answer-key-url").value;
    var answers = document.getElementById("participant-answers").value.split(',');

    if (!url || answers.length === 0) {
        alert("Please enter the answer key URL and your answers.");
        return;
    }

    const API_URL = 'https://your-backend-url.com/fetch-key';  // Update with your real backend URL

    fetch(API_URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ "url": url, "answers": answers })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            document.getElementById("results").innerHTML = `<p>Error: ${data.error}</p>`;
        } else {
            let resultHTML = `<h3>Performance Breakdown:</h3>
                              <ul>
                                  <li>Total Score: ${data.total_score}</li>
                                  <li>Rank: ${data.rank}</li>
                              </ul>
                              <h3>Subject-wise Breakdown:</h3>`;
            
            for (const [subject, performance] of Object.entries(data.performance_breakdown)) {
                resultHTML += `
                    <ul>
                        <li>Subject: ${subject}</li>
                        <li>Correct Answers: ${performance.correct_answers}</li>
                        <li>Incorrect Answers: ${performance.incorrect_answers}</li>
                        <li>Score: ${performance.score}</li>
                    </ul>
                `;
            }

            document.getElementById("results").innerHTML = resultHTML;
        }
    })
    .catch(error => {
        document.getElementById("results").innerHTML = `<p>Error: ${error.message}</p>`;
    });
});
