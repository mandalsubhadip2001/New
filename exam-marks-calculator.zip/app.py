from flask import Flask, request, jsonify
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)

# Example stored participant data (for ranking)
participants_scores = [
    {"name": "Participant 1", "score": 80},
    {"name": "Participant 2", "score": 90},
    {"name": "Participant 3", "score": 70},
    {"name": "Participant 4", "score": 85},
]

# Example answer key with subjects (Modify to match real data)
subject_answer_key = {
    "Math": ["A", "B", "C", "D", "A"],  # Example
    "Science": ["B", "C", "A", "D", "C"],
}

def calculate_score_and_breakdown(answers, answer_key, negative_marking=True):
    score = 0
    subject_performance = {}

    for subject, correct_answers in answer_key.items():
        subject_score = 0
        incorrect_answers = 0

        for i, answer in enumerate(answers.get(subject, [])):
            if answer == correct_answers[i]:
                subject_score += 1
            else:
                incorrect_answers += 1

        # Calculate negative marking (if enabled)
        if negative_marking:
            subject_score -= incorrect_answers * 0.25  # Assuming 0.25 negative marking

        subject_performance[subject] = {
            "score": subject_score,
            "correct_answers": len([a for a in answers.get(subject, []) if a == correct_answers[i]]),
            "incorrect_answers": incorrect_answers,
        }

        score += subject_score  # Total score

    return score, subject_performance

@app.route('/fetch-key', methods=['POST'])
def fetch_answer_key():
    data = request.json
    url = data.get('url')
    participant_answers = data.get('answers')

    if not url or not participant_answers:
        return jsonify({"error": "URL and answers are required"}), 400

    response = requests.get(url)
    if response.status_code != 200:
        return jsonify({"error": "Failed to fetch the URL"}), 500

    soup = BeautifulSoup(response.text, 'html.parser')
    answer_key = {}

    for subject_div in soup.find_all('div', class_='subject'):
        subject_name = subject_div.find('h2').text.strip()
        answers = [answer.text.strip() for answer in subject_div.find_all('li')]
        answer_key[subject_name] = answers

    total_score, performance_breakdown = calculate_score_and_breakdown(participant_answers, answer_key)

    rank = "Not Ranked"
    sorted_participants = sorted(participants_scores, key=lambda x: x["score"], reverse=True)
    for i, participant in enumerate(sorted_participants):
        if participant["score"] == total_score:
            rank = f"Rank {i+1}"
            break

    return jsonify({
        "performance_breakdown": performance_breakdown,
        "total_score": total_score,
        "rank": rank
    }), 200

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
